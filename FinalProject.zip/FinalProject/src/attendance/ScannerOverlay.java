package attendance;

import javax.swing.*;
import java.awt.*;

public class ScannerOverlay extends JPanel {

    private int laserY = 90;
    private Timer timer;

    public ScannerOverlay() {

        setOpaque(false);

        timer = new Timer(15, e -> {

            laserY += 2;

            if (laserY > 390) {
                laserY = 90;
            }

            repaint();

        });

        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        int boxWidth = 300;
        int boxHeight = 300;

        int x = (w - boxWidth) / 2;
        int y = (h - boxHeight) / 2;

        
        g2.setColor(new Color(0, 0, 0, 120));
        g2.fillRect(0, 0, w, h);

   
        Composite old = g2.getComposite();

        g2.setComposite(AlphaComposite.Clear);
        g2.fillRect(x, y, boxWidth, boxHeight);

        g2.setComposite(old);

       
        g2.setColor(Color.GREEN);
        g2.setStroke(new BasicStroke(3));
        g2.drawRect(x, y, boxWidth, boxHeight);

        // Corner lines

        int c = 30;

        // Top Left
        g2.drawLine(x, y, x + c, y);
        g2.drawLine(x, y, x, y + c);

        // Top Right
        g2.drawLine(x + boxWidth, y,
                x + boxWidth - c, y);
        g2.drawLine(x + boxWidth, y,
                x + boxWidth, y + c);

        // Bottom Left
        g2.drawLine(x, y + boxHeight,
                x + c, y + boxHeight);
        g2.drawLine(x, y + boxHeight,
                x, y + boxHeight - c);

        // Bottom Right
        g2.drawLine(x + boxWidth, y + boxHeight,
                x + boxWidth - c,
                y + boxHeight);
        g2.drawLine(x + boxWidth, y + boxHeight,
                x + boxWidth,
                y + boxHeight - c);

        
        g2.setColor(Color.GREEN);
        g2.setStroke(new BasicStroke(2));
        g2.drawLine(x + 5, laserY, x + boxWidth - 5, laserY);

        
        g2.setFont(new Font("Arial", Font.BOLD, 20));
        g2.setColor(Color.WHITE);

        String text = "Place QR Code Inside Green Box";

        FontMetrics fm = g2.getFontMetrics();

        g2.drawString(
                text,
                (w - fm.stringWidth(text)) / 2,
                y - 20);

        // Bottom hint
        g2.setFont(new Font("Arial", Font.PLAIN, 14));

        String hint = "QR Attendance Scanner";

        FontMetrics fm2 = g2.getFontMetrics();

        g2.drawString(
                hint,
                (w - fm2.stringWidth(hint)) / 2,
                y + boxHeight + 30);
    }

    public void stopAnimation() {

        if (timer != null) {
            timer.stop();
        }

    }
}