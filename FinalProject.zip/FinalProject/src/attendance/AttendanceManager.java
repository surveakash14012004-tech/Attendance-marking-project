package attendance;

import database.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class AttendanceManager {

    public static boolean markAttendance(String qrData) {

        System.out.println("=================================");
        System.out.println("QR Data Received : " + qrData);

        try (Connection con = DBConnection.getConnection()) {

            
            String studentQuery =
                    "SELECT id, name FROM students WHERE qr_data=?";

            try (PreparedStatement ps = con.prepareStatement(studentQuery)) {

                ps.setString(1, qrData);

                ResultSet rs = ps.executeQuery();

                if (!rs.next()) {

                    System.out.println("Student Not Found!");
                    return false;
                }

                int studentId = rs.getInt("id");
                String studentName = rs.getString("name");

                System.out.println("Student Found : " + studentName);

        
                String checkQuery =
                        "SELECT id FROM attendance WHERE student_id=? AND attendance_date=?";

                try (PreparedStatement check = con.prepareStatement(checkQuery)) {

                    check.setInt(1, studentId);
                    check.setDate(2, Date.valueOf(LocalDate.now()));

                    ResultSet checkRs = check.executeQuery();

                    if (checkRs.next()) {

                        System.out.println("Attendance Already Marked");

                        return true;
                    }
                }

               
                String insertQuery =
                        "INSERT INTO attendance(student_id, attendance_date, attendance_time, status) VALUES(?,?,?,?)";

                try (PreparedStatement insert = con.prepareStatement(insertQuery)) {

                    insert.setInt(1, studentId);
                    insert.setDate(2, Date.valueOf(LocalDate.now()));
                    insert.setTime(3, Time.valueOf(LocalTime.now()));
                    insert.setString(4, "Present");

                    int rows = insert.executeUpdate();

                    if (rows > 0) {

                        System.out.println("Attendance Marked Successfully");
                        return true;

                    } else {

                        System.out.println("Attendance Not Inserted");
                        return false;
                    }
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}