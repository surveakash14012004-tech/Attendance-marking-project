package attendance;

import database.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AttendanceTable extends JFrame {

    private JTable table;
    private DefaultTableModel model;

    public AttendanceTable() {

        setTitle("Attendance Report");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel();

        model.addColumn("Student ID");
        model.addColumn("Name");
        model.addColumn("Roll No");
        model.addColumn("Department");
        model.addColumn("Date");
        model.addColumn("Time");
        model.addColumn("Status");

        table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);

        JButton btnRefresh = new JButton("Refresh");

        btnRefresh.addActionListener(e -> loadAttendance());

        add(scrollPane, BorderLayout.CENTER);
        add(btnRefresh, BorderLayout.SOUTH);

        loadAttendance();

        setVisible(true);
    }

    private void loadAttendance() {

        model.setRowCount(0);

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                    "SELECT s.id, s.name, s.roll_no, s.department, " +
                    "a.attendance_date, a.attendance_time, a.status " +
                    "FROM attendance a " +
                    "JOIN students s ON a.student_id = s.id " +
                    "ORDER BY a.attendance_date DESC, a.attendance_time DESC";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                model.addRow(new Object[]{

                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("roll_no"),
                        rs.getString("department"),
                        rs.getDate("attendance_date"),
                        rs.getTime("attendance_time"),
                        rs.getString("status")

                });

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

            JOptionPane.showMessageDialog(this,
                    "Error loading attendance!");

        }

    }

}