package attendance;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;

import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import javax.imageio.ImageIO;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;

import java.awt.image.BufferedImage;

import java.io.File;

import java.text.SimpleDateFormat;

import java.util.Collections;
import java.util.Date;
import java.util.EnumMap;
import java.util.Map;

public class QRScanner extends JFrame {

    // ============================================================
    // WEBCAM
    // ============================================================

    private Webcam webcam;

    private WebcamPanel webcamPanel;

    private Thread scanThread;

    private volatile boolean scannerRunning = false;

    private volatile boolean processingQR = false;

    // ============================================================
    // GUI
    // ============================================================

    private JLabel statusLabel;

    private JLayeredPane layeredPane;

    private JLabel capturedImageLabel;

    // ============================================================
    // CAMERA
    // ============================================================

    private static final int CAMERA_WIDTH = 640;

    private static final int CAMERA_HEIGHT = 480;

    // ============================================================
    // GREEN BOX
    // ============================================================

    private static final int SCAN_WIDTH = 300;

    private static final int SCAN_HEIGHT = 300;

    // ============================================================
    // CAPTURE
    // ============================================================

    private static final int CAPTURE_FRAMES = 8;

    private static final int CAPTURE_DELAY = 40;

    // ============================================================
    // CAPTURED QR DISPLAY
    // ============================================================

    private static final int DISPLAY_SIZE = 300;

    // ============================================================
    // ZXING
    // ============================================================

    private final MultiFormatReader reader =
            new MultiFormatReader();

    private final Map<DecodeHintType, Object> hints;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    public QRScanner() {

        setTitle(
                "Smart QR Attendance Scanner"
        );

        setSize(
                720,
                680
        );

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        setResizable(false);

        setLayout(
                new BorderLayout()
        );

        // ========================================================
        // ZXING SETTINGS
        // ========================================================

        hints =
                new EnumMap<>(
                        DecodeHintType.class
                );

        hints.put(
                DecodeHintType.POSSIBLE_FORMATS,
                Collections.singletonList(
                        BarcodeFormat.QR_CODE
                )
        );

        reader.setHints(
                hints
        );

        // ========================================================
        // STATUS LABEL
        // ========================================================

        statusLabel =
                new JLabel(
                        "Initializing Camera...",
                        SwingConstants.CENTER
                );

        statusLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        statusLabel.setBorder(
                new EmptyBorder(
                        5,
                        5,
                        8,
                        5
                )
        );

        // ========================================================
        // FIND CAMERA
        // ========================================================

        webcam =
                Webcam.getDefault();

        if (webcam == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No Webcam Found!",
                    "Camera Error",
                    JOptionPane.ERROR_MESSAGE
            );

            dispose();

            return;
        }

        // ========================================================
        // CAMERA RESOLUTION
        // ========================================================

        try {

            webcam.setViewSize(
                    new Dimension(
                            CAMERA_WIDTH,
                            CAMERA_HEIGHT
                    )
            );

        } catch (Exception e) {

            e.printStackTrace();
        }

        // ========================================================
        // WEBCAM PANEL
        // ========================================================

        webcamPanel =
                new WebcamPanel(
                        webcam,
                        false
                );

        webcamPanel.setFPSDisplayed(
                false
        );

        webcamPanel.setMirrored(
                false
        );

        webcamPanel.setFillArea(
                true
        );

        webcamPanel.setBounds(
                0,
                0,
                CAMERA_WIDTH,
                CAMERA_HEIGHT
        );

        // ========================================================
        // LAYERED PANE
        // ========================================================

        layeredPane =
                new JLayeredPane();

        layeredPane.setPreferredSize(
                new Dimension(
                        CAMERA_WIDTH,
                        CAMERA_HEIGHT
                )
        );

        layeredPane.add(
                webcamPanel,
                Integer.valueOf(0)
        );

        // ========================================================
        // GREEN BOX
        // ========================================================

        ScannerOverlay overlay =
                new ScannerOverlay();

        overlay.setBounds(
                0,
                0,
                CAMERA_WIDTH,
                CAMERA_HEIGHT
        );

        layeredPane.add(
                overlay,
                Integer.valueOf(1)
        );

        // ========================================================
        // CAPTURED IMAGE
        // ========================================================

        capturedImageLabel =
                new JLabel();

        capturedImageLabel.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        capturedImageLabel.setVerticalAlignment(
                SwingConstants.CENTER
        );

        capturedImageLabel.setOpaque(
                true
        );

        capturedImageLabel.setBackground(
                Color.WHITE
        );

        capturedImageLabel.setBorder(
                BorderFactory.createLineBorder(
                        Color.GREEN,
                        5
                )
        );

        capturedImageLabel.setVisible(
                false
        );

        layeredPane.add(
                capturedImageLabel,
                Integer.valueOf(2)
        );

        add(
                layeredPane,
                BorderLayout.CENTER
        );

        // ========================================================
        // BOTTOM PANEL
        // ========================================================

        JPanel bottomPanel =
                new JPanel(
                        new BorderLayout()
                );

        bottomPanel.setBorder(
                new EmptyBorder(
                        5,
                        10,
                        8,
                        10
                )
        );

        bottomPanel.add(
                statusLabel,
                BorderLayout.NORTH
        );

        // ========================================================
        // BUTTONS
        // ========================================================

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                5
                        )
                );

        JButton loadQRButton =
                new JButton(
                        "Load QR Image"
                );

        JButton clearButton =
                new JButton(
                        "Clear Image"
                );

        JButton closeButton =
                new JButton(
                        "Close"
                );

        loadQRButton.setPreferredSize(
                new Dimension(
                        145,
                        35
                )
        );

        clearButton.setPreferredSize(
                new Dimension(
                        130,
                        35
                )
        );

        closeButton.setPreferredSize(
                new Dimension(
                        100,
                        35
                )
        );

        buttonPanel.add(
                loadQRButton
        );

        buttonPanel.add(
                clearButton
        );

        buttonPanel.add(
                closeButton
        );

        bottomPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        add(
                bottomPanel,
                BorderLayout.SOUTH
        );

        // ========================================================
        // LOAD QR IMAGE
        // ========================================================

        loadQRButton.addActionListener(
                e -> loadAndDecodeQRImage()
        );

        // ========================================================
        // CLEAR
        // ========================================================

        clearButton.addActionListener(
                e -> clearCapturedImage()
        );

        // ========================================================
        // CLOSE
        // ========================================================

        closeButton.addActionListener(
                e -> closeScanner()
        );

        // ========================================================
        // SHOW
        // ========================================================

        setVisible(
                true
        );

        // ========================================================
        // START CAMERA
        // ========================================================

        startCamera();
    }

    // ============================================================
    // START CAMERA
    // ============================================================

    private void startCamera() {

        try {

            statusLabel.setText(
                    "Opening Camera..."
            );

            webcam.open();

            webcamPanel.start();

            scannerRunning = true;

            statusLabel.setText(
                    "Place QR Code Inside Green Box"
            );

            startWebcamScanner();

        } catch (Exception e) {

            e.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to open webcam:\n"
                            + e.getMessage(),
                    "Camera Error",
                    JOptionPane.ERROR_MESSAGE
            );

            dispose();
        }
    }

    // ============================================================
    // START QR SCANNER
    // ============================================================

    private void startWebcamScanner() {

        scanThread =
                new Thread(
                        () -> {

                            while (
                                    scannerRunning
                                            &&
                                    !processingQR
                            ) {

                                try {

                                    if (
                                            webcam == null
                                                    ||
                                            !webcam.isOpen()
                                    ) {

                                        Thread.sleep(
                                                20
                                        );

                                        continue;
                                    }

                                    BufferedImage frame =
                                            webcam.getImage();

                                    if (frame == null) {

                                        continue;
                                    }

                                    // ==================================
                                    // ONLY QR BOX AREA
                                    // ==================================

                                    BufferedImage qrArea =
                                            cropCenter(
                                                    frame
                                            );

                                    // ==================================
                                    // QUICK QR DETECTION
                                    // ==================================

                                    Result detected =
                                            quickDetect(
                                                    qrArea
                                            );

                                    if (detected != null) {

                                        SwingUtilities.invokeLater(
                                                () -> {

                                                    statusLabel.setText(
                                                            "QR Detected - Capturing..."
                                                    );

                                                }
                                        );

                                        // ==================================
                                        // CAPTURE BEST FRAME
                                        // ==================================

                                        CaptureResult capture =
                                                captureBestFrame();

                                        if (
                                                capture != null
                                                        &&
                                                capture.fullFrame != null
                                        ) {

                                            processingQR = true;

                                            /*
                                             * Display QR area.
                                             */

                                            SwingUtilities.invokeLater(
                                                    () -> {

                                                        showCapturedImage(
                                                                capture.qrImage
                                                        );

                                                        statusLabel.setText(
                                                                "QR Captured - Processing..."
                                                        );

                                                    }
                                            );

                                            /*
                                             * Decode the captured QR.
                                             */

                                            processCapturedImage(
                                                    capture.qrImage,
                                                    capture.fullFrame
                                            );

                                            break;
                                        }
                                    }

                                    Thread.yield();

                                } catch (
                                        InterruptedException e
                                ) {

                                    Thread.currentThread()
                                            .interrupt();

                                    break;

                                } catch (Exception e) {

                                    e.printStackTrace();

                                }
                            }

                        },
                        "QR-Webcam-Scanner"
                );

        scanThread.setDaemon(
                true
        );

        scanThread.start();
    }

    // ============================================================
    // CAPTURE RESULT
    // ============================================================

    private static class CaptureResult {

        BufferedImage fullFrame;

        BufferedImage qrImage;

        double sharpness;

        CaptureResult(
                BufferedImage fullFrame,
                BufferedImage qrImage,
                double sharpness
        ) {

            this.fullFrame =
                    fullFrame;

            this.qrImage =
                    qrImage;

            this.sharpness =
                    sharpness;
        }
    }

    // ============================================================
    // CAPTURE BEST FRAME
    // ============================================================

    private CaptureResult captureBestFrame()
            throws InterruptedException {

        BufferedImage bestFullFrame =
                null;

        BufferedImage bestQR =
                null;

        double bestSharpness =
                -1;

        for (
                int i = 0;
                i < CAPTURE_FRAMES;
                i++
        ) {

            if (!scannerRunning) {

                return null;
            }

            BufferedImage frame =
                    webcam.getImage();

            if (frame == null) {

                continue;
            }

            /*
             * Save the FULL frame.
             *
             * This is the photograph of the person.
             */

            BufferedImage fullCopy =
                    copyImage(
                            frame
                    );

            /*
             * Crop only QR area for decoding.
             */

            BufferedImage qrArea =
                    cropCenter(
                            frame
                    );

            double sharpness =
                    calculateSharpness(
                            qrArea
                    );

            if (
                    sharpness
                            >
                    bestSharpness
            ) {

                bestSharpness =
                        sharpness;

                bestFullFrame =
                        fullCopy;

                bestQR =
                        copyImage(
                                qrArea
                        );
            }

            Thread.sleep(
                    CAPTURE_DELAY
            );
        }

        if (
                bestFullFrame == null
                        ||
                bestQR == null
        ) {

            return null;
        }

        return new CaptureResult(
                bestFullFrame,
                bestQR,
                bestSharpness
        );
    }

    // ============================================================
    // QUICK QR DETECTION
    // ============================================================

    private Result quickDetect(
            BufferedImage image
    ) {

        try {

            LuminanceSource source =
                    new BufferedImageLuminanceSource(
                            image
                    );

            BinaryBitmap bitmap =
                    new BinaryBitmap(
                            new HybridBinarizer(
                                    source
                            )
                    );

            reader.reset();

            reader.setHints(
                    hints
            );

            return reader.decode(
                    bitmap
            );

        } catch (Exception e) {

            return null;
        }
    }

    // ============================================================
    // PROCESS CAPTURED QR
    // ============================================================

    private void processCapturedImage(
            BufferedImage qrImage,
            BufferedImage fullPersonImage
    ) {

        new Thread(
                () -> {

                    // ==============================================
                    // DECODE QR
                    // ==============================================

                    Result result =
                            decodeImage(
                                    qrImage
                            );

                    // ==============================================
                    // TRY GRAYSCALE
                    // ==============================================

                    if (result == null) {

                        BufferedImage gray =
                                convertToGrayscale(
                                        qrImage
                                );

                        result =
                                decodeImage(
                                        gray
                                );
                    }

                    // ==============================================
                    // DECODE FAILED
                    // ==============================================

                    if (result == null) {

                        SwingUtilities.invokeLater(
                                () -> {

                                    statusLabel.setText(
                                            "QR Captured - Decode Failed"
                                    );

                                    JOptionPane.showMessageDialog(
                                            this,
                                            "QR image was captured, "
                                                    +
                                                    "but it could not be decoded.\n\n"
                                                    +
                                                    "Place the complete QR inside "
                                                    +
                                                    "the green box and try again.",
                                            "QR Decode Failed",
                                            JOptionPane.WARNING_MESSAGE
                                    );

                                    resetScanner();

                                }
                        );

                        return;
                    }

                    // ==============================================
                    // GET QR DATA
                    // ==============================================

                    String qrData =
                            result.getText();

                    System.out.println(
                            "QR Data = "
                                    +
                                    qrData
                    );

                    // ==============================================
                    // MARK ATTENDANCE
                    // ==============================================

                    try {

                        boolean success =
                                AttendanceManager
                                        .markAttendance(
                                                qrData
                                        );

                        if (success) {

                            /*
                             * Attendance succeeded.
                             *
                             * NOW SAVE THE PERSON'S FULL PHOTO.
                             */

                            File photoFile =
                                    saveAttendancePhoto(
                                            fullPersonImage,
                                            qrData
                                    );

                            SwingUtilities.invokeLater(
                                    () -> {

                                        statusLabel.setText(
                                                "Attendance Marked Successfully"
                                        );

                                        String photoMessage;

                                        if (
                                                photoFile != null
                                        ) {

                                            photoMessage =
                                                    "\n\nVerification Photo Saved:\n"
                                                            +
                                                            photoFile.getName();

                                        } else {

                                            photoMessage =
                                                    "\n\nWarning: Verification photo "
                                                            +
                                                            "could not be saved.";

                                        }

                                        JOptionPane.showMessageDialog(
                                                this,
                                                "Attendance Marked Successfully!"
                                                        +
                                                        "\n\nRoll / QR: "
                                                        +
                                                        qrData
                                                        +
                                                        photoMessage,
                                                "Success",
                                                JOptionPane.INFORMATION_MESSAGE
                                        );

                                        closeScanner();

                                    }
                            );

                        } else {

                            SwingUtilities.invokeLater(
                                    () -> {

                                        statusLabel.setText(
                                                "Student Not Found"
                                        );

                                        JOptionPane.showMessageDialog(
                                                this,
                                                "Student Not Found!\n\n"
                                                        +
                                                        qrData,
                                                "Attendance Error",
                                                JOptionPane.ERROR_MESSAGE
                                        );

                                        resetScanner();

                                    }
                            );
                        }

                    } catch (Exception e) {

                        e.printStackTrace();

                        SwingUtilities.invokeLater(
                                () -> {

                                    JOptionPane.showMessageDialog(
                                            this,
                                            "Database Error:\n"
                                                    +
                                                    e.getMessage(),
                                            "Error",
                                            JOptionPane.ERROR_MESSAGE
                                    );

                                    resetScanner();

                                }
                        );
                    }

                },
                "Captured-QR-Processor"
        ).start();
    }

    // ============================================================
    // SAVE ATTENDANCE PHOTO
    // ============================================================

    private File saveAttendancePhoto(
            BufferedImage image,
            String rollNumber
    ) {

        try {

            /*
             * Project root:
             *
             * FinalProject/
             */

            String projectPath =
                    System.getProperty(
                            "user.dir"
                    );

            File folder =
                    new File(
                            projectPath,
                            "attendance_photos"
                    );

            /*
             * Create folder if necessary.
             */

            if (!folder.exists()) {

                boolean created =
                        folder.mkdirs();

                if (!created) {

                    System.out.println(
                            "Could not create attendance_photos folder."
                    );

                    return null;
                }
            }

            // ==============================================
            // TIMESTAMP
            // ==============================================

            String timestamp =
                    new SimpleDateFormat(
                            "yyyy-MM-dd_HH-mm-ss"
                    ).format(
                            new Date()
                    );

            /*
             * Remove characters that are not safe
             * for a Windows filename.
             */

            String safeRoll =
                    rollNumber.replaceAll(
                            "[^a-zA-Z0-9_-]",
                            "_"
                    );

            /*
             * Example:
             *
             * 123_2026-08-11_22-30-15.jpg
             */

            String fileName =
                    safeRoll
                            +
                            "_"
                            +
                            timestamp
                            +
                            ".jpg";

            File photoFile =
                    new File(
                            folder,
                            fileName
                    );

            boolean saved =
                    ImageIO.write(
                            image,
                            "jpg",
                            photoFile
                    );

            if (saved) {

                System.out.println(
                        "===================================="
                );

                System.out.println(
                        "Attendance Photo Saved"
                );

                System.out.println(
                        "Roll/QR: "
                                +
                                rollNumber
                );

                System.out.println(
                        "Photo: "
                                +
                                photoFile
                                        .getAbsolutePath()
                );

                System.out.println(
                        "===================================="
                );

                return photoFile;

            } else {

                return null;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return null;
        }
    }

    // ============================================================
    // DECODE IMAGE
    // ============================================================

    private Result decodeImage(
            BufferedImage image
    ) {

        try {

            LuminanceSource source =
                    new BufferedImageLuminanceSource(
                            image
                    );

            BinaryBitmap bitmap =
                    new BinaryBitmap(
                            new HybridBinarizer(
                                    source
                            )
                    );

            reader.reset();

            reader.setHints(
                    hints
            );

            return reader.decode(
                    bitmap
            );

        } catch (Exception e) {

            return null;
        }
    }

    // ============================================================
    // DISPLAY CAPTURED QR
    // ============================================================

    private void showCapturedImage(
            BufferedImage image
    ) {

        Image scaled =
                image.getScaledInstance(
                        DISPLAY_SIZE,
                        DISPLAY_SIZE,
                        Image.SCALE_SMOOTH
                );

        capturedImageLabel.setIcon(
                new javax.swing.ImageIcon(
                        scaled
                )
        );

        int x =
                (
                        CAMERA_WIDTH
                                -
                        DISPLAY_SIZE
                ) / 2;

        int y =
                (
                        CAMERA_HEIGHT
                                -
                        DISPLAY_SIZE
                ) / 2;

        capturedImageLabel.setBounds(
                x,
                y,
                DISPLAY_SIZE,
                DISPLAY_SIZE
        );

        capturedImageLabel.setVisible(
                true
        );

        layeredPane.repaint();
    }

    // ============================================================
    // LOAD QR IMAGE
    // ============================================================

    private void loadAndDecodeQRImage() {

        JFileChooser chooser =
                new JFileChooser();

        chooser.setDialogTitle(
                "Select QR Code Image"
        );

        chooser.setFileFilter(
                new FileNameExtensionFilter(
                        "QR Images (*.png, *.jpg, *.jpeg)",
                        "png",
                        "jpg",
                        "jpeg"
                )
        );

        int result =
                chooser.showOpenDialog(
                        this
                );

        if (
                result
                        !=
                JFileChooser.APPROVE_OPTION
        ) {

            return;
        }

        File file =
                chooser.getSelectedFile();

        new Thread(
                () -> {

                    try {

                        statusLabel.setText(
                                "Loading QR Image..."
                        );

                        BufferedImage image =
                                ImageIO.read(
                                        file
                                );

                        if (image == null) {

                            JOptionPane.showMessageDialog(
                                    this,
                                    "Invalid image file.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE
                            );

                            return;
                        }

                        /*
                         * Display uploaded QR.
                         */

                        SwingUtilities.invokeLater(
                                () -> {

                                    showCapturedImage(
                                            image
                                    );

                                }
                        );

                        /*
                         * Decode immediately.
                         */

                        Result qrResult =
                                decodeImage(
                                        image
                                );

                        if (qrResult == null) {

                            BufferedImage gray =
                                    convertToGrayscale(
                                            image
                                    );

                            qrResult =
                                    decodeImage(
                                            gray
                                    );
                        }

                        if (qrResult != null) {

                            processingQR = true;

                            /*
                             * For uploaded QR image there is no
                             * new webcam capture.
                             *
                             * Capture current person from webcam.
                             */

                            BufferedImage personImage =
                                    webcam.getImage();

                            if (personImage == null) {

                                JOptionPane.showMessageDialog(
                                        this,
                                        "Could not capture person image from webcam.",
                                        "Camera Error",
                                        JOptionPane.ERROR_MESSAGE
                                );

                                resetScanner();

                                return;
                            }

                            processCapturedImage(
                                    image,
                                    copyImage(
                                            personImage
                                    )
                            );

                        } else {

                            SwingUtilities.invokeLater(
                                    () -> {

                                        statusLabel.setText(
                                                "QR Not Detected"
                                        );

                                        JOptionPane.showMessageDialog(
                                                this,
                                                "QR code could not be decoded.",
                                                "QR Error",
                                                JOptionPane.WARNING_MESSAGE
                                        );

                                    }
                            );
                        }

                    } catch (Exception e) {

                        e.printStackTrace();

                        SwingUtilities.invokeLater(
                                () -> {

                                    JOptionPane.showMessageDialog(
                                            this,
                                            "Error reading QR image:\n"
                                                    +
                                                    e.getMessage(),
                                            "Error",
                                            JOptionPane.ERROR_MESSAGE
                                    );

                                }
                        );
                    }

                },
                "QR-Image-Loader"
        ).start();
    }

    // ============================================================
    // GRAYSCALE
    // ============================================================

    private BufferedImage convertToGrayscale(
            BufferedImage original
    ) {

        BufferedImage gray =
                new BufferedImage(
                        original.getWidth(),
                        original.getHeight(),
                        BufferedImage.TYPE_BYTE_GRAY
                );

        Graphics2D graphics =
                gray.createGraphics();

        graphics.drawImage(
                original,
                0,
                0,
                null
        );

        graphics.dispose();

        return gray;
    }

    // ============================================================
    // CROP CENTER
    // ============================================================

    private BufferedImage cropCenter(
            BufferedImage frame
    ) {

        int width =
                Math.min(
                        SCAN_WIDTH,
                        frame.getWidth()
                );

        int height =
                Math.min(
                        SCAN_HEIGHT,
                        frame.getHeight()
                );

        int x =
                (
                        frame.getWidth()
                                -
                        width
                ) / 2;

        int y =
                (
                        frame.getHeight()
                                -
                        height
                ) / 2;

        return copyImage(
                frame.getSubimage(
                        x,
                        y,
                        width,
                        height
                )
        );
    }

    // ============================================================
    // COPY IMAGE
    // ============================================================

    private BufferedImage copyImage(
            BufferedImage source
    ) {

        BufferedImage copy =
                new BufferedImage(
                        source.getWidth(),
                        source.getHeight(),
                        BufferedImage.TYPE_INT_RGB
                );

        Graphics2D graphics =
                copy.createGraphics();

        graphics.drawImage(
                source,
                0,
                0,
                null
        );

        graphics.dispose();

        return copy;
    }

    // ============================================================
    // SHARPNESS
    // ============================================================

    private double calculateSharpness(
            BufferedImage image
    ) {

        int width =
                image.getWidth();

        int height =
                image.getHeight();

        long total =
                0;

        int count =
                0;

        for (
                int y = 1;
                y < height - 1;
                y += 2
        ) {

            for (
                    int x = 1;
                    x < width - 1;
                    x += 2
            ) {

                int center =
                        getGray(
                                image,
                                x,
                                y
                        );

                int left =
                        getGray(
                                image,
                                x - 1,
                                y
                        );

                int right =
                        getGray(
                                image,
                                x + 1,
                                y
                        );

                int top =
                        getGray(
                                image,
                                x,
                                y - 1
                        );

                int bottom =
                        getGray(
                                image,
                                x,
                                y + 1
                        );

                int laplacian =
                        Math.abs(
                                left
                                        +
                                right
                                        +
                                top
                                        +
                                bottom
                                        -
                                4 * center
                        );

                total +=
                        laplacian;

                count++;
            }
        }

        if (count == 0) {

            return 0;
        }

        return (
                (double) total
                        /
                count
        );
    }

    // ============================================================
    // GRAY
    // ============================================================

    private int getGray(
            BufferedImage image,
            int x,
            int y
    ) {

        int rgb =
                image.getRGB(
                        x,
                        y
                );

        int r =
                (rgb >> 16)
                        &
                        0xFF;

        int g =
                (rgb >> 8)
                        &
                        0xFF;

        int b =
                rgb
                        &
                        0xFF;

        return (
                r * 299
                        +
                g * 587
                        +
                b * 114
        ) / 1000;
    }

    // ============================================================
    // RESET
    // ============================================================

    private void resetScanner() {

        processingQR = false;

        SwingUtilities.invokeLater(
                () -> {

                    capturedImageLabel.setVisible(
                            false
                    );

                    capturedImageLabel.setIcon(
                            null
                    );

                    statusLabel.setText(
                            "Place QR Code Inside Green Box"
                    );

                    layeredPane.repaint();

                }
        );
    }

    // ============================================================
    // CLEAR IMAGE
    // ============================================================

    private void clearCapturedImage() {

        capturedImageLabel.setIcon(
                null
        );

        capturedImageLabel.setVisible(
                false
        );

        processingQR = false;

        statusLabel.setText(
                "Place QR Code Inside Green Box"
        );

        layeredPane.repaint();
    }

    // ============================================================
    // CLOSE
    // ============================================================

    private void closeScanner() {

        scannerRunning = false;

        processingQR = true;

        try {

            if (scanThread != null) {

                scanThread.interrupt();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {

            if (webcamPanel != null) {

                webcamPanel.stop();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {

            if (
                    webcam != null
                            &&
                    webcam.isOpen()
            ) {

                webcam.close();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        dispose();
    }

    // ============================================================
    // DISPOSE
    // ============================================================

    @Override
    public void dispose() {

        scannerRunning = false;

        try {

            if (scanThread != null) {

                scanThread.interrupt();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {

            if (webcamPanel != null) {

                webcamPanel.stop();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {

            if (
                    webcam != null
                            &&
                    webcam.isOpen()
            ) {

                webcam.close();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        super.dispose();
    }

    // ============================================================
    // MAIN
    // ============================================================

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(
                () -> {

                    new QRScanner();

                }
        );
    }
}