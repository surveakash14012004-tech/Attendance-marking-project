package utils;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.client.j2se.MatrixToImageWriter;

import java.io.File;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class QRGenerator {

    public static String generateQR(String qrData) {

        try {

            
            File folder = new File("qr_codes");

            if (!folder.exists()) {

                boolean created = folder.mkdirs();

                if (created) {
                    System.out.println("Folder Created : " + folder.getAbsolutePath());
                }

            }

            
            File qrFile = new File(folder, qrData + ".png");

            Path path = qrFile.toPath();

            
            Map<EncodeHintType, Object> hints = new HashMap<>();

            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.MARGIN, 1);

            
            BitMatrix bitMatrix = new MultiFormatWriter().encode(
                    qrData,
                    BarcodeFormat.QR_CODE,
                    300,
                    300,
                    hints);

           
            MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);

            System.out.println("====================================");
            System.out.println("QR Code Generated Successfully");
            System.out.println("QR Data : " + qrData);
            System.out.println("Saved At : " + qrFile.getAbsolutePath());
            System.out.println("====================================");

            return qrFile.getAbsolutePath();

        } catch (Exception e) {

            System.out.println("QR Generation Failed");
            e.printStackTrace();

            return null;
        }
    }
}