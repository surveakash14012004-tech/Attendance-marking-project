package student;

import database.DBConnection;
import utils.QRGenerator;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StudentRegistration extends JFrame {

    JTextField txtName;
    JTextField txtRoll;
    JTextField txtDepartment;

    JButton btnRegister;
    JButton btnReset;

    public StudentRegistration() {

        setTitle("Student Registration");
        setSize(450, 350);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lbl1 = new JLabel("Name");
        JLabel lbl2 = new JLabel("Roll No");
        JLabel lbl3 = new JLabel("Department");

        txtName = new JTextField();
        txtRoll = new JTextField();
        txtDepartment = new JTextField();

        btnRegister = new JButton("Register");
        btnReset = new JButton("Reset");

        lbl1.setBounds(40, 40, 100, 25);
        txtName.setBounds(150, 40, 220, 25);

        lbl2.setBounds(40, 90, 100, 25);
        txtRoll.setBounds(150, 90, 220, 25);

        lbl3.setBounds(40, 140, 100, 25);
        txtDepartment.setBounds(150, 140, 220, 25);

        btnRegister.setBounds(80, 220, 120, 35);
        btnReset.setBounds(230, 220, 120, 35);

        add(lbl1);
        add(lbl2);
        add(lbl3);

        add(txtName);
        add(txtRoll);
        add(txtDepartment);

        add(btnRegister);
        add(btnReset);

        btnRegister.addActionListener(e -> registerStudent());

        btnReset.addActionListener(e -> clearFields());

        setVisible(true);
    }

    private void clearFields() {
        txtName.setText("");
        txtRoll.setText("");
        txtDepartment.setText("");
    }

    private void registerStudent() {

        String name = txtName.getText().trim();
        String roll = txtRoll.getText().trim();
        String dept = txtDepartment.getText().trim();

        if (name.isEmpty() || roll.isEmpty() || dept.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fill all fields.",
                    "Validation",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;
        PreparedStatement check = null;
        ResultSet rs = null;

        try {

            con = DBConnection.getConnection();

            
            check = con.prepareStatement(
                    "SELECT roll_no FROM students WHERE roll_no=?");
            check.setString(1, roll);

            rs = check.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this,
                        "Roll Number already exists.");
                return;
            }

            String qrData = roll;

            String sql =
                    "INSERT INTO students(name, roll_no, department, qr_data) VALUES(?,?,?,?)";

            ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setString(2, roll);
            ps.setString(3, dept);
            ps.setString(4, qrData);

            ps.executeUpdate();

            
            QRGenerator.generateQR(qrData);

            JOptionPane.showMessageDialog(this,
                    "Student Registered Successfully!\n\nQR Code Saved Successfully.");

            clearFields();

        }
        catch (Exception ex) {

            ex.printStackTrace();

            JOptionPane.showMessageDialog(this,
                    "Database Error:\n" + ex.getMessage());

        }
        finally {

            try { if (rs != null) rs.close(); } catch (Exception e) {}

            try { if (check != null) check.close(); } catch (Exception e) {}

            try { if (ps != null) ps.close(); } catch (Exception e) {}

            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StudentRegistration::new);
    }
}