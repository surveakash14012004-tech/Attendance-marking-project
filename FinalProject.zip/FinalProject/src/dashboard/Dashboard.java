package dashboard;

import attendance.AttendanceTable;
import attendance.QRScanner;
import login.LoginFrame;
import student.StudentRegistration;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Dashboard extends JFrame {

    public Dashboard() {

        setTitle("Smart Attendance System");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // ================= Main Panel =================

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 248, 252));

        // ================= Header =================

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(13, 71, 161));
        header.setPreferredSize(new Dimension(900, 100));
        header.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Logo
        JLabel logo = new JLabel();

        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/images/mit_logo.png"));
            Image img = icon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
            logo.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            logo.setText("MIT");
            logo.setForeground(Color.WHITE);
            logo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        }

        header.add(logo, BorderLayout.WEST);

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("SMART ATTENDANCE SYSTEM");
        title.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("QR Code Based Attendance Management");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitle.setForeground(Color.WHITE);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(5));
        titlePanel.add(subtitle);

        header.add(titlePanel, BorderLayout.CENTER);

        // Admin
      //  JLabel admin = new JLabel("Admin");
      //  admin.setFont(new Font("Segoe UI", Font.BOLD, 22));
      //  admin.setForeground(Color.WHITE);

       // header.add(admin, BorderLayout.EAST);

        // ================= Center =================

        JPanel center = new JPanel();
        center.setBackground(new Color(245, 248, 252));
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));

        center.add(Box.createVerticalStrut(30));

        JLabel welcome = new JLabel("Welcome Back !");
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 26));
        welcome.setForeground(new Color(40, 40, 40));

        center.add(welcome);

        center.add(Box.createVerticalStrut(35));

        JButton btnRegister = createButton("Student Registration");
        JButton btnScan = createButton("Scan QR Attendance");
        JButton btnAttendance = createButton("Attendance Report");
        JButton btnLogout = createButton("Logout");

        btnRegister.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnScan.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnAttendance.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogout.setAlignmentX(Component.CENTER_ALIGNMENT);

        center.add(btnRegister);
        center.add(Box.createVerticalStrut(20));

        center.add(btnScan);
        center.add(Box.createVerticalStrut(20));

        center.add(btnAttendance);
        center.add(Box.createVerticalStrut(20));

        center.add(btnLogout);

        // ================= Footer =================

        JPanel footer = new JPanel();

        footer.setBackground(new Color(13, 71, 161));
        footer.setPreferredSize(new Dimension(900, 45));

        JLabel footerText = new JLabel(
                "© 2026 Smart Attendance System | MIT University, Pune");

        footerText.setForeground(Color.WHITE);
        footerText.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        footer.add(footerText);

        // ================= Add Panels =================

        mainPanel.add(header, BorderLayout.NORTH);
        mainPanel.add(center, BorderLayout.CENTER);
        mainPanel.add(footer, BorderLayout.SOUTH);

        add(mainPanel);

        // ================= Button Actions =================

        btnRegister.addActionListener(e -> new StudentRegistration());

        btnScan.addActionListener(e -> new QRScanner());

        btnAttendance.addActionListener(e -> new AttendanceTable());

        btnLogout.addActionListener(e -> {
            dispose();
            new LoginFrame();
        });

        setVisible(true);
    }

    // ================= Button Design =================

    private JButton createButton(String text) {

        JButton button = new JButton(text);

        button.setPreferredSize(new Dimension(320, 50));
        button.setMaximumSize(new Dimension(320, 50));

        button.setBackground(new Color(25, 118, 210));
        button.setForeground(Color.WHITE);

        button.setFont(new Font("Segoe UI", Font.BOLD, 18));

        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.setBorder(BorderFactory.createEmptyBorder());

        button.addMouseListener(new java.awt.event.MouseAdapter() {

            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(13, 71, 161));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(25, 118, 210));
            }
        });

        return button;
    }
}