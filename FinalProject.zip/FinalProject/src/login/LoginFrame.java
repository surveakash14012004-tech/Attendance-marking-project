package login;

import dashboard.Dashboard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class LoginFrame extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JCheckBox showPassword;

    private Image backgroundImage;

    public LoginFrame() {

    	ImageIcon icon = new ImageIcon("src/resources/images/mitadt.jpeg");

      
    	backgroundImage = new ImageIcon(
    	        getClass().getResource("/images/mitadt.jpeg"))
    	        .getImage();
    	
    	
        setTitle("Smart Attendance System");

        setSize(1000, 600);

        setLocationRelativeTo(null);

        setResizable(false);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel backgroundPanel = new JPanel() {

            @Override
            protected void paintComponent(Graphics g) {

                super.paintComponent(g);

                g.drawImage(backgroundImage,
                        0,
                        0,
                        getWidth(),
                        getHeight(),
                        this);
            }

        };

        backgroundPanel.setLayout(null);

        JPanel loginPanel = new JPanel();

        loginPanel.setLayout(null);

        loginPanel.setBackground(Color.WHITE);

        loginPanel.setBounds(620, 90, 320, 380);

        JLabel lblTitle =
                new JLabel("SMART ATTENDANCE");

        lblTitle.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        22));

        lblTitle.setForeground(
                new Color(25,60,160));

        lblTitle.setBounds(35,25,260,30);

        JLabel lblUser =
                new JLabel("Username");

        lblUser.setFont(
                new Font("Segoe UI",
                        Font.PLAIN,
                        15));

        lblUser.setBounds(35,80,120,20);

        txtUsername = new JTextField();

        txtUsername.setFont(
                new Font("Segoe UI",
                        Font.PLAIN,
                        15));

        txtUsername.setBounds(35,105,250,35);

        JLabel lblPass =
                new JLabel("Password");

        lblPass.setFont(
                new Font("Segoe UI",
                        Font.PLAIN,
                        15));

        lblPass.setBounds(35,155,120,20);

        txtPassword =
                new JPasswordField();

        txtPassword.setFont(
                new Font("Segoe UI",
                        Font.PLAIN,
                        15));

        txtPassword.setBounds(35,180,250,35);

        showPassword =
                new JCheckBox("Show Password");

        showPassword.setBackground(Color.WHITE);

        showPassword.setBounds(35,225,160,25);

        showPassword.addActionListener(e -> {

            if(showPassword.isSelected()){

                txtPassword.setEchoChar((char)0);

            }else{

                txtPassword.setEchoChar('•');
            }

        });

        btnLogin =
                new JButton("LOGIN");

        btnLogin.setBounds(80,280,160,42);

        btnLogin.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        16));

        btnLogin.setBackground(
                new Color(37,99,235));

        btnLogin.setForeground(Color.WHITE);

        btnLogin.setFocusPainted(false);

        btnLogin.setCursor(
                new Cursor(Cursor.HAND_CURSOR));

        btnLogin.addActionListener(
                (ActionEvent e)->login());

        loginPanel.add(lblTitle);
        loginPanel.add(lblUser);
        loginPanel.add(txtUsername);
        loginPanel.add(lblPass);
        loginPanel.add(txtPassword);
        loginPanel.add(showPassword);
        loginPanel.add(btnLogin);

        backgroundPanel.add(loginPanel);

        add(backgroundPanel);

        setVisible(true);
    }

    
    private void login() {

        String username = txtUsername.getText().trim();
        String password = String.valueOf(txtPassword.getPassword());

        
        if (username.equals("admin") && password.equals("admin123")) {

            JOptionPane.showMessageDialog(
                    this,
                    "Login Successful",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            dispose();

            new Dashboard();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Invalid Username or Password",
                    "Login Failed",
                    JOptionPane.ERROR_MESSAGE);

            txtPassword.setText("");
            txtPassword.requestFocus();

        }
    }
    }    